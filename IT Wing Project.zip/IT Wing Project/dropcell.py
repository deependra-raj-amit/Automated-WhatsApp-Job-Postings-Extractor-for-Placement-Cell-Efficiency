import pandas as pd
import os

# Load the Excel file
file_path = r"C:\Users\DEEPENDRA\Downloads\extracted_job_postings.xlsx"

# Check if the file exists before reading
if os.path.exists(file_path):
    df = pd.read_excel(file_path)

    # Print the column names
    print("Column names in the file:")
    print(df.columns.tolist())

    # Print the original DataFrame size
    print("Original DataFrame size:", df.shape)

    # Drop rows with any empty cells
    cleaned_df = df.dropna()

    # Print the cleaned DataFrame to see if it has any data
    print("DataFrame after dropping empty cells:")
    print(cleaned_df)

    # Save the cleaned data to a new Excel file
    cleaned_file_path = r"C:\Users\DEEPENDRA\Downloads\cleaned_job_postings.xlsx"

    try:
        cleaned_df.to_excel(cleaned_file_path, index=False)
        print("Cleaning process completed. Cleaned data saved to:", cleaned_file_path)
    except PermissionError:
        print(f"Permission error: Please make sure '{cleaned_file_path}' is not open or that you have permission to write to this location.")
else:
    print(f"File not found at: {file_path}")
