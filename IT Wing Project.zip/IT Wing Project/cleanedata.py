import pandas as pd

# Load the existing structured data from the provided Excel file path
input_file_path = r'C:/Users/DEEPENDRA/Downloads/structured_whatsapp_data.xlsx'
structured_data = pd.read_excel(input_file_path)

# Drop rows where all columns are NaN
structured_data_cleaned = structured_data.dropna(how='all')

# Save the cleaned DataFrame to a new Excel file
output_file_path = r'C:/Users/DEEPENDRA/Downloads/cleaned_structured_data.xlsx'
structured_data_cleaned.to_excel(output_file_path, index=False)

print(f'Cleaned data saved to: {output_file_path}')
