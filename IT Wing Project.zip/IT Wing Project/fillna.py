import pandas as pd
import os

# Load the Excel file
file_path = r"C:\Users\DEEPENDRA\Downloads\extracted_job_postings.xlsx"

# Check if the file exists before reading
if os.path.exists(file_path):
    df = pd.read_excel(file_path)

    # Print the column names
    print("Column names in the file:")
    print(df.columns.tolist())

    # Print the original DataFrame size
    print("Original DataFrame size:", df.shape)

    # Fill all empty cells with 'NA'
    filled_df = df.fillna('NA')

    # Print the DataFrame after filling empty cells
    print("DataFrame after filling empty cells with 'NA':")
    print(filled_df)

    # Save the modified data to a new Excel file
    filled_file_path = r"C:\Users\DEEPENDRA\Downloads\filled_job_postings.xlsx"

    try:
        filled_df.to_excel(filled_file_path, index=False)
        print("Filling process completed. Data saved to:", filled_file_path)
    except PermissionError:
        print(f"Permission error: Please make sure '{filled_file_path}' is not open or that you have permission to write to this location.")
else:
    print(f"File not found at: {file_path}")
