import pandas as pd
import os

# Load the Excel file
file_path = r"C:\Users\DEEPENDRA\Downloads\extracted_job_postings.xlsx"

# Check if the file exists before reading
if os.path.exists(file_path):
    df = pd.read_excel(file_path)

    # Print the column names
    print("Column names in the file:")
    print(df.columns.tolist())

    # Fill all empty cells with 'NA'
    filled_df = df.fillna('NA')

    # Print the DataFrame after filling empty cells
    print("DataFrame after filling empty cells with 'NA':")
    print(filled_df)

    # Remove columns that contain only 'NA' values
    cleaned_df = filled_df.dropna(axis=1, how='all')

    # Print the DataFrame after dropping columns with only 'NA' values
    print("DataFrame after dropping columns with only 'NA' values:")
    print(cleaned_df)

    # Save the modified data to a new Excel file
    cleaned_file_path = r"C:\Users\DEEPENDRA\Downloads\cleaned_job_postings_no_na_columns.xlsx"

    try:
        cleaned_df.to_excel(cleaned_file_path, index=False)
        print("Cleaning process completed. Data saved to:", cleaned_file_path)
    except PermissionError:
        print(f"Permission error: Please make sure '{cleaned_file_path}' is not open or that you have permission to write to this location.")
else:
    print(f"File not found at: {file_path}")
