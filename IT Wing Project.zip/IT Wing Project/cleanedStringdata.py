import pandas as pd
import os

# Load the Excel file
file_path = r"C:\Users\DEEPENDRA\Downloads\extracted_job_postings.xlsx"

# Check if the file exists before reading
if os.path.exists(file_path):
    df = pd.read_excel(file_path)

    # Print the column names
    print("Column names in the file:")
    print(df.columns.tolist())

    # Specify the columns to check for non-empty values
    required_columns = ["Qualification", "Experience", "Location", "Salary", "Mail ID"]

    # Check for NaN values in the required columns
    na_counts = df[required_columns].isna().sum()
    print("NaN counts in required columns:")
    print(na_counts)

    # Keep rows where required columns are not NaN and not empty strings
    filtered_df = df[df[required_columns].notna().all(axis=1) & (df[required_columns].astype(bool).all(axis=1))]

    # Print the filtered DataFrame to see if it has any data
    print("Filtered DataFrame:")
    print(filtered_df)

    # Save the filtered data to a new Excel file
    cleaned_file_path = r"C:\Users\DEEPENDRA\Downloads\filtered_job_postings_qualification_experience.xlsx"

    try:
        filtered_df.to_excel(cleaned_file_path, index=False)
        print("Filtering process completed. Filtered data saved to:", cleaned_file_path)
    except PermissionError:
        print(f"Permission error: Please make sure '{cleaned_file_path}' is not open or that you have permission to write to this location.")
else:
    print(f"File not found at: {file_path}")
