import pandas as pd
import re

# Load the WhatsApp chat data
whatsapp_chat_data = pd.read_excel(r'C:/Users/DEEPENDRA/Downloads/WhatsApp Chat with S.K.I.N. 1 CAREER WING.xlsx')

# Initialize an empty dataframe with the desired format's structure
columns = ['Date', 'Company Name', 'Roles', 'Count', 'Experience', 'Qualification', 'CTC', 'Location', 'Mail id', 'Cell No', 'Name']
structured_data = pd.DataFrame(columns=columns)

# Regex patterns to extract the necessary information
date_pattern = r'(\d{4}-\d{2}-\d{2})'  # For date extraction
company_pattern = r'(?:urgent|opening|requirement|vacancy|hiring|needed) in (.*?)(?:\.|,|@)'  # For company name extraction
role_pattern = r'(?i)(?:role|position|requirement|opening|vacancy):? (.*?)(?:\.|,|$)'  # For roles extraction
experience_pattern = r'experience\s?[:\-]? (\d+.*?years?)'
qualification_pattern = r'qualification\s?[:\-]? (.*?)(?:\.|,|$)'
ctc_pattern = r'ctc\s?[:\-]? (.*?)(?:\.|,|$)'
location_pattern = r'location\s?[:\-]? (.*?)(?:\.|,|$)'
email_pattern = r'[\w\.-]+@[\w\.-]+\.\w+'  # Email pattern
phone_pattern = r'\+?\d[\d -]{8,12}\d'  # Phone number pattern

# List to accumulate the rows to be added
rows_to_add = []

# Process each row in the WhatsApp chat data
for index, row in whatsapp_chat_data.iterrows():
    message = str(row.iloc[0])  # Use iloc to safely access the first element
    
    # Extract data based on patterns
    date_match = re.search(date_pattern, message)
    company_match = re.search(company_pattern, message)
    role_match = re.search(role_pattern, message)
    experience_match = re.search(experience_pattern, message)
    qualification_match = re.search(qualification_pattern, message)
    ctc_match = re.search(ctc_pattern, message)
    location_match = re.search(location_pattern, message)
    email_match = re.search(email_pattern, message)
    phone_match = re.search(phone_pattern, message)
    
    # Append extracted data as a dictionary to the list
    rows_to_add.append({
        'Date': date_match.group(1) if date_match else None,
        'Company Name': company_match.group(1).strip() if company_match else None,
        'Roles': role_match.group(1).strip() if role_match else None,
        'Experience': experience_match.group(1) if experience_match else None,
        'Qualification': qualification_match.group(1).strip() if qualification_match else None,
        'CTC': ctc_match.group(1).strip() if ctc_match else None,
        'Location': location_match.group(1).strip() if location_match else None,
        'Mail id': email_match.group(0) if email_match else None,
        'Cell No': phone_match.group(0) if phone_match else None,
        'Name': None  # You can further modify the script to extract names if needed
    })

# After gathering all rows, use pd.concat to add them to the dataframe
structured_data = pd.concat([structured_data, pd.DataFrame(rows_to_add)], ignore_index=True)

# Save the structured data to a new Excel file
output_path = 'C:/Users/DEEPENDRA/Downloads/structured_whatsapp_data.xlsx'
structured_data.to_excel(output_path, index=False)
print(f'Structured data saved to: {output_path}')




