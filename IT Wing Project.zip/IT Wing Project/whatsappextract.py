import pandas as pd
import re

# Path to the text file
file_path = r"C:\Users\DEEPENDRA\Downloads\WhatsApp Chat with S.K.I.N. 1 CAREER WING.txt"

# Regular expression patterns for extraction
patterns = {
    "Company Name": r"(?:Company Name:|Company:|Organization:|Employer:)\s*(.*?)(?=\n|$)",
    "Job Roles": r"(?:Position\s*:\s*|Job Role\s*:\s*|Role\s*:\s*)(.*?)(?=\n|$)",
    "Job Openings": r"(?:Vacant\s*:\s*|Openings\s*:\s*)(.*?)(?=\n|$)",
    "Qualification": r"(?:Qualification\s*:\s*|Qualifications\s*:\s*|Degree\s*:\s*)(.*?)(?=\n|$)",
    "Experience": r"(?:Experience\s*:\s*|Exp\s*:\s*|Years of Experience\s*:\s*)(.*?)(?=\n|$)",
    "Location": r"(?:Location\s*:\s*|Based\s*:\s*|City\s*:\s*)(.*?)(?=\n|$)",
    "Salary": r"(?:Package\s*:\s*|Salary\s*:\s*|Compensation\s*:\s*)(.*?)(?=\n|$)",
    "Mail ID": r"(?:Email\s*:\s*|Mail\s*:\s*)([\w\.-]+@[\w\.-]+)(?=\s|$)",
    "Cell No.": r"(?:Contact\s*:\s*|Mobile\s*:\s*|Phone\s*:\s*)(\+?\d[\d\s-]*)",
    "Name": r"(?:Dear\s*|Hello\s*|Hi\s*|Greetings\s*)(.*?)\s*[\n:]",  # Adjusted to capture names
}

# Create a DataFrame to hold the extracted data
data = []

# Read the text file
with open(file_path, 'r', encoding='latin-1') as file:
    lines = file.readlines()

# Prepare a temporary dictionary to hold the job data
job_data = {key: None for key in patterns.keys()}

# Loop through each line in the text file
for line in lines:
    # Loop through each pattern to extract data
    for key, pattern in patterns.items():
        match = re.search(pattern, line, re.IGNORECASE)
        if match and len(match.groups()) > 0:  # Check if there's at least one group
            job_data[key] = match.group(1).strip()
    
    # If a line is empty or a new job listing starts, save the data
    if not line.strip() or "new job" in line.lower():  # Change condition as needed to identify new job posts
        if any(value is not None for value in job_data.values()):  # Check if any data is filled
            data.append(job_data)
            job_data = {key: None for key in patterns.keys()}  # Reset for the next job posting

# Handle any remaining job data after the loop
if any(value is not None for value in job_data.values()):
    data.append(job_data)

# Create a DataFrame from the extracted data
df = pd.DataFrame(data)

# Save the DataFrame to an Excel file
output_file_path = r"C:\Users\DEEPENDRA\Downloads\extracted_job_postings.xlsx"
df.to_excel(output_file_path, index=False)

print(f"Data extracted and saved to {output_file_path}")
